package com.myclass.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.myclass.entity.User;
import com.myclass.repository.UserRepository;

@Repository
public class UserRepositoryImpl implements UserRepository{

	private List<User> list = null;
	
	public UserRepositoryImpl() {
		list = new ArrayList<User>();
		list.add(new User(1, "teo@gmail.com", "Nguyễn Văn Tèo", "123456", "", "", "", 1));
	}
	
	public List<User> findAll() {
		return list;
	}

	public User findById(int id) {
		for(User user: list) {
			if(user.getId() == id) {
				return user;
			}
		}
		return null;
	}

	public void save(User model) {
		list.add(model);
	}

	public void delete(int id) {
		User user = this.findById(id);
		if(user != null) {
			list.remove(user);
		}
	}

	public void update(User model) {
		User user = findById(model.getId());
		user.setEmail(model.getEmail());
		user.setFullname(model.getFullname());
		user.setAddress(model.getAddress());
		user.setPhone(model.getPhone());
		user.setRoleId(model.getRoleId());
	}

}
