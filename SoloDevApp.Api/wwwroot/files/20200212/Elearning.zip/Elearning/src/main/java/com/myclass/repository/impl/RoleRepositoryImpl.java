package com.myclass.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.myclass.entity.Role;
import com.myclass.repository.RoleRepository;

@Repository
public class RoleRepositoryImpl implements RoleRepository{

	private List<Role> list = null;
	
	public RoleRepositoryImpl() {
		list = new ArrayList<Role>();
		list.add(new Role(1, "ROLE_ADMIN", "Quản trị"));
		list.add(new Role(2, "ROLE_TEACHER", "Giảng viên"));
		list.add(new Role(3, "ROLE_STUDENT", "Học viên"));
	}
	
	public List<Role> findAll() {
		return list;
	}

	public Role findById(int id) {
		for(Role role: list) {
			if(role.getId() == id) {
				return role;
			}
		}
		return null;
	}

	public void save(Role model) {
		list.add(model);
	}

	public void delete(int id) {
		Role role = this.findById(id);
		if(role != null) {
			list.remove(role);
		}
	}

	public void update(Role model) {
		Role role = findById(model.getId());
		role.setName(model.getName());
		role.setDescription(model.getDescription());
	}
}
