package com.myclass.admin.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.myclass.entity.Role;
import com.myclass.repository.RoleRepository;

@Controller
@RequestMapping("admin/role")
public class AdminRoleController {
	
	@Autowired
	private RoleRepository roleRepository;

	@GetMapping("")
	public String index(ModelMap model) {
		model.addAttribute("roles", roleRepository.findAll());
		return "role-index";
	}

	@GetMapping("add")
	public String add(ModelMap model) {
		model.addAttribute("role", new Role());
		return "role-add";
	}

	@PostMapping("add")
	public String add(ModelMap model, @Valid @ModelAttribute("role") Role role, BindingResult errors) {
		// Nếu có lỗi
		if (errors.hasErrors()) {
			return "role-add";
		}
		roleRepository.save(role);
		return "redirect:/admin/role";
	}

	// Lấy thông tin role theo id
	@GetMapping("edit")
	public String edit(@RequestParam int id, ModelMap model) {
		Role role = roleRepository.findById(id);
		model.addAttribute("role", role);
		return "role-edit";
	}

	@PostMapping("edit")
	public String edit(ModelMap model, @Valid @ModelAttribute("role") Role role, BindingResult errors) {
		// Nếu có lỗi
		if (errors.hasErrors()) {
			return "role-edit";
		}
		roleRepository.update(role);
		return "redirect:/admin/role";
	}

	// Lấy thông tin role theo id
	@GetMapping("delete")
	public String delete(@RequestParam int id) {
		roleRepository.delete(id);
		return "redirect:/admin/role";
	}
}
