package com.myclass.repository;

import java.util.List;

import com.myclass.entity.Role;

public interface RoleRepository {
	public List<Role> findAll();
	public Role findById(int id);
	public void save(Role model);
	public void delete(int id);
	public void update(Role model);
}
